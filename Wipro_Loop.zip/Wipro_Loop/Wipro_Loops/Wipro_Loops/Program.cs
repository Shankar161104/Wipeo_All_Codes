﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wipro_Loops
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for(int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i);
            }

            for (int i = 1; i <10; i++)
            {
                Console.WriteLine(i);
            }

            for(int i = 10; i >= 1; i--)
            {

                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}

1 1
1 2
1 3
2 1
2 2
2 3
3 1
3 2
3 3