﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public interface IStaffRepository
    {
        IEnumerable<Staff> GetAllStaffs();
        Staff GetStaffById(int id);
        void InsertStaff(Staff staff);
        void UpdateStaff(Staff staff);
        void DeleteStaff(int id);
        void Save();
    }
}
