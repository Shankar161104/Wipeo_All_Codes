﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepository;
        private readonly IMemberRepository _memberRepository; // Add this if you have a Member repository

        public AuthService(IUserRepository userRepository, IMemberRepository memberRepository)
        {
            _userRepository = userRepository;
            _memberRepository = memberRepository;
        }

        public bool ValidateUser(string username, string password)
        {
            // Check for User in UserRepository
            var user = _userRepository.GetUserByUsernameAndPassword(username, password);

            // Check for Member in MemberRepository
            var member = _memberRepository.GetMemberByUsername(username); // Ensure this method checks both username and password
            bool isValidMember = member != null && member.Password == password; // Compare password

            return user != null || isValidMember; // Return true if either a User or a Member
        }


        public bool IsMember(string username)
        {
            // Check if the username exists in the Member table
            var member = _memberRepository.GetMemberByUsername(username);
            return member != null; // Assuming the presence of a member means the user is a member
        }
    }
}
