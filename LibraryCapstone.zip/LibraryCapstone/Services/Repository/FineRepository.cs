﻿using DAL.EntityFrameWork;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public class FineRepository : IFineRepository
    {
        private readonly LibraryDbContext _libraryDbContext;

        public FineRepository(LibraryDbContext libraryDbContext)
        {
            _libraryDbContext = libraryDbContext;
        }

        public IEnumerable<Fine> GetAllFines()
        {
            return _libraryDbContext.Fines.ToList();
        }

        public Fine GetFineById(int id)
        {
            return _libraryDbContext.Fines.Find(id);
        }

        public void InsertFine(Fine fine)
        {
            _libraryDbContext.Fines.Add(fine);
        }

        public void UpdateFine(Fine fine)
        {
            _libraryDbContext.Entry(fine).State = EntityState.Modified;
        }

        public void DeleteFine(int id)
        {
            var fine = _libraryDbContext.Fines.Find(id);
            if (fine != null)
            {
                _libraryDbContext.Fines.Remove(fine);
            }
        }

        public void Save()
        {
            _libraryDbContext.SaveChanges();
        }
    }
}
