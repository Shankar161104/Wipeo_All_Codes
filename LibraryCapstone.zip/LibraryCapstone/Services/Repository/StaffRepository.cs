﻿using DAL.EntityFrameWork;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public class StaffRepository : IStaffRepository
    {
        private readonly LibraryDbContext libraryDbContext;

        public StaffRepository(LibraryDbContext _libraryDbContext)
        {
            libraryDbContext = _libraryDbContext;
        }

        public IEnumerable<Staff> GetAllStaffs()
        {
            return libraryDbContext.Staffs.ToList();
        }

        public Staff GetStaffById(int id)
        {
            return libraryDbContext.Staffs.Find(id);
        }

        public void InsertStaff(Staff staff)
        {
            libraryDbContext.Staffs.Add(staff);
        }

        public void UpdateStaff(Staff staff)
        {
            libraryDbContext.Entry(staff).State = EntityState.Modified;
        }

        public void DeleteStaff(int id)
        {
            var staff = libraryDbContext.Staffs.Find(id);
            if (staff != null)
            {
                libraryDbContext.Staffs.Remove(staff);
            }
        }

        public void Save()
        {
            libraryDbContext.SaveChanges();
        }
    }
}
