﻿using DAL.EntityFrameWork;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public class BookRepository : IBookRepository
    {
        private readonly LibraryDbContext libraryDbContext;

        public BookRepository(LibraryDbContext _libraryDbContext)
        {
            libraryDbContext = _libraryDbContext;
        }

        public IEnumerable<Book> GetAllBooks()
        {
            return libraryDbContext.Books.ToList();
        }

        public Book GetBookById(int id)
        {
            return libraryDbContext.Books.Find(id);
        }

        public void InsertBook(Book book)
        {
            libraryDbContext.Books.Add(book);
        }

        public void UpdateBook(Book book)
        {
            libraryDbContext.Entry(book).State = EntityState.Modified;
        }

        public void DeleteBook(int id)
        {
            var book = libraryDbContext.Books.Find(id);
            if (book != null)
            {
                libraryDbContext.Books.Remove(book);
            }
        }

        public void Save()
        {
            libraryDbContext.SaveChanges();
        }
    }
}
