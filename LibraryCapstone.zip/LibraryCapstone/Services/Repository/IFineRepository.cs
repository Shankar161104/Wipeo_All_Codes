﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public interface IFineRepository
    {
        IEnumerable<Fine> GetAllFines();
        Fine GetFineById(int id);
        void InsertFine(Fine fine);
        void UpdateFine(Fine fine);
        void DeleteFine(int id);
        void Save();
    }
}
