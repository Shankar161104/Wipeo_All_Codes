﻿namespace Services.Repository
{
    public interface IAuthService
    {
        bool ValidateUser(string username, string password);
        bool IsMember(string username); // New method
    }
}
