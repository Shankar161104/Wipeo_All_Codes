﻿using DAL.EntityFrameWork;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public class MemberRepository : IMemberRepository
    {
        private readonly LibraryDbContext _libraryDbContext;

        public MemberRepository(LibraryDbContext libraryDbContext)
        {
            _libraryDbContext = libraryDbContext;
        }

        public void AddMember(Member member)
        {
            _libraryDbContext.Members.Add(member); // Add the member entity to the DbContext
            _libraryDbContext.SaveChanges(); // Save the changes to the database
        }


        public Member GetMemberByUsername(string username)
        {
            // Adjust based on how you store the Username in your Member table
            return _libraryDbContext.Members.FirstOrDefault(m => m.Username == username);
        }
        public IEnumerable<Member> GetAllMembers()
        {
            return _libraryDbContext.Members.ToList();
        }

        public Member GetMemberById(int id)
        {
            return _libraryDbContext.Members.Find(id);
        }

        public void InsertMember(Member member)
        {
            _libraryDbContext.Members.Add(member);
        }

        public void UpdateMember(Member member)
        {
            _libraryDbContext.Entry(member).State = EntityState.Modified;
        }

        public void DeleteMember(int id)
        {
            var member = _libraryDbContext.Members.Find(id);
            if (member != null)
            {
                _libraryDbContext.Members.Remove(member);
            }
        }

        public void Save()
        {
            _libraryDbContext.SaveChanges();
        }
    }
}
