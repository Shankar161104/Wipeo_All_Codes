﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public interface IBookIssueRepository
    {
        IEnumerable<BookIssue> GetAllBookIssues();
        BookIssue GetBookIssueById(int id);
        void InsertBookIssue(BookIssue bookIssue);
        void UpdateBookIssue(BookIssue bookIssue);
        void DeleteBookIssue(int id);
        void Save();
    }
}
