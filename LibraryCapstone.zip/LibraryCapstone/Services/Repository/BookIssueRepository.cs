﻿using DAL.EntityFrameWork;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public class BookIssueRepository : IBookIssueRepository
    {
        private readonly LibraryDbContext libraryDbContext;

        public BookIssueRepository(LibraryDbContext _libraryDbContext)
        {
            libraryDbContext = _libraryDbContext;
        }

        public IEnumerable<BookIssue> GetAllBookIssues()
        {
            return libraryDbContext.BookIssues.ToList();
        }

        public BookIssue GetBookIssueById(int id)
        {
            return libraryDbContext.BookIssues.Find(id);
        }

        public void InsertBookIssue(BookIssue bookIssue)
        {
            libraryDbContext.BookIssues.Add(bookIssue);
        }

        public void UpdateBookIssue(BookIssue bookIssue)
        {
            libraryDbContext.Entry(bookIssue).State = EntityState.Modified;
        }

        public void DeleteBookIssue(int id)
        {
            var bookIssue = libraryDbContext.BookIssues.Find(id);
            if (bookIssue != null)
            {
                libraryDbContext.BookIssues.Remove(bookIssue);
            }
        }

        public void Save()
        {
            libraryDbContext.SaveChanges();
        }
    }
}
