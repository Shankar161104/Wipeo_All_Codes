﻿using System.ComponentModel.DataAnnotations;

namespace LibraryCapstone.Models
{
    public class MemberRegistrationViewModel
    {
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required]
        public string PhoneNumber { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        public string Username { get; set; }

        public DateTime MembershipDate { get; set; } = DateTime.Now;
    }
}
