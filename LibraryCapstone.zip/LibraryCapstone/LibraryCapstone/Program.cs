using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using DAL.EntityFrameWork; // Adjust based on your context
using LibraryCapstone.Models;
using Services.Repository;
using Domain.Models; // Adjust based on your context

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add DbContext with SQL Server
builder.Services.AddDbContext<LibraryDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("LibraryConnection"),
    sqlOptions => sqlOptions.MigrationsAssembly("LibraryCapstone")));

// Register Repositories and Services
builder.Services.AddTransient<IBookRepository, BookRepository>();
builder.Services.AddTransient<IBookIssueRepository, BookIssueRepository>();
builder.Services.AddTransient<IStaffRepository, StaffRepository>();
builder.Services.AddTransient<IMemberRepository, MemberRepository>();
builder.Services.AddTransient<IFineRepository, FineRepository>();
builder.Services.AddTransient<IUserRepository, UserRepository>();
builder.Services.AddTransient<IAuthService, AuthService>();

// Add Distributed Memory Cache (required for session management)
builder.Services.AddDistributedMemoryCache(); // Ensure this is added

// Add Session Services
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout
    options.Cookie.HttpOnly = true; // Make the session cookie HttpOnly
    options.Cookie.IsEssential = true; // Make the session cookie essential
});

// Configure Authentication
builder.Services.AddAuthentication("CookieAuth")
    .AddCookie("CookieAuth", config =>
    {
        config.Cookie.Name = "LibraryCapstone.Cookie";
        config.LoginPath = "/Auth/Login";
        config.LogoutPath = "/Auth/Logout"; // Add a logout path
    });

var app = builder.Build();

// Seed the database with a default user
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<LibraryDbContext>();
    dbContext.Database.Migrate(); // Ensure database is created and migrated
    SeedData(dbContext); // Call seed method
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts(); // Add HSTS for production security
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Use Authentication and Authorization Middleware
app.UseAuthentication();
app.UseAuthorization();

// Use Session Middleware
app.UseSession(); // Ensure this is before UseEndpoints or MapControllerRoute

// Map Default Controller Route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Auth}/{action=Login}/{id?}");

app.Run();

// Seed data method
void SeedData(LibraryDbContext context)
{
    if (!context.Users.Any()) // Check if there are any users
    {
        context.Users.Add(new User
        {
            UserName = "admin",
            Password = "admin123", // Plain text for demonstration; use hashing in production
            Role = "Admin"
        });
        context.SaveChanges();
    }
}
