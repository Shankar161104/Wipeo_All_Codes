﻿using Domain.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services.Repository;

namespace LibraryCapstone.APIController
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookAPIController : ControllerBase
    {
        private readonly IBookRepository _bookRepository;

        public BookAPIController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

        // GET: api/BookAPI
        [HttpGet]
        public ActionResult<IEnumerable<Book>> GetBooks()
        {
            var books = _bookRepository.GetAllBooks();
            return Ok(books);
        }

        // GET: api/BookAPI/5
        [HttpGet("{id}")]
        public ActionResult<Book> GetBook(int id)
        {
            var book = _bookRepository.GetBookById(id);
            if (book == null)
            {
                return NotFound();
            }
            return Ok(book);
        }

        // POST: api/BookAPI
        [HttpPost]
        public async Task<ActionResult<Book>> PostBook(Book book)
        {
            _bookRepository.InsertBook(book);
            _bookRepository.Save();

            return CreatedAtAction(nameof(GetBook), new { id = book.BookId }, book);
        }

        // PUT: api/BookAPI/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBook(int id, Book book)
        {
            if (id != book.BookId)
            {
                return BadRequest();
            }

            _bookRepository.UpdateBook(book);
            _bookRepository.Save();

            return NoContent();
        }

        // DELETE: api/BookAPI/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var book = _bookRepository.GetBookById(id);
            if (book == null)
            {
                return NotFound();
            }

            _bookRepository.DeleteBook(id);
            _bookRepository.Save();

            return NoContent();
        }
    }
}
