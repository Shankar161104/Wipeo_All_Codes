﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services.Repository;

namespace LibraryCapstone.APIController
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthAPIController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthAPIController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("Login")]
        public IActionResult Login(string username, string password)
        {
            if (_authService.ValidateUser(username, password))
            {
                return Ok("Login Successful");
            }
            return Unauthorized("Invalid credentials");
        }
    }
}
