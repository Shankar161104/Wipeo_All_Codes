﻿using Microsoft.AspNetCore.Mvc;
using Services.Repository;
using Domain.Models;
using LibraryCapstone.Models;

namespace LibraryCapstone.Controllers
{
    public class MemberController : Controller
    {
        private readonly IBookRepository _bookRepository;

        private readonly IMemberRepository _memberRepository;

        public MemberController(IBookRepository bookRepository, IMemberRepository memberRepository)
        {
            _bookRepository = bookRepository;
            _memberRepository = memberRepository;

        }

        // GET: Member/BooksListForMember
        public IActionResult BooksListForMember()
        {
            var books = _bookRepository.GetAllBooks();
            return View(books); // Return the view with the list of books
        }
        // GET: Member/Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: Member/Register
        [HttpPost]
        public IActionResult Register(MemberRegistrationViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Map ViewModel to Member entity
                var member = new Member
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber,
                    Password = model.Password, // Hash this in a real application
                    Username = model.Username,
                    MembershipDate = model.MembershipDate
                };

                // Add member to the repository and save to the database
                _memberRepository.AddMember(member);

                // Redirect to login or another page after registration
                return RedirectToAction("Login", "Auth");
            }

            return View(model);
        }
    }
}
