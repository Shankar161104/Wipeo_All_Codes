﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models
{
    public class Fine
    {
        public int FineId { get; set; }
        public int BookIssueId { get; set; }
        public int Amount { get; set; }
        public DateTime IssuedDate { get; set; }
    }

}
