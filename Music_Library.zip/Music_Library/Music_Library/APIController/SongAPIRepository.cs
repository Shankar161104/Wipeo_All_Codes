﻿using Domain.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services.Repository;

namespace Music_Library.APIController
{
    [Route("api/[controller]")]
    [ApiController]
    public class SongAPIRepository : ControllerBase
    {
        private readonly ISongRepository songRepository;
        public SongAPIRepository(ISongRepository _songRepository)
        {
            songRepository = _songRepository;
        }

        [HttpGet("GetSongs")]

        public ActionResult GetSongs()
        {
            return Ok(songRepository.GetSongs());
        }

        [HttpPost("Create")]

        public ActionResult CreateSong(Song song)
        {
            return Ok(songRepository.CreateSong(song));
        }

        [HttpDelete("Delete")]

        public ActionResult DeleteSong(int id)
        {
            return Ok(songRepository.DeleteSong(id));
        }

        [HttpPost("Update")]

        public ActionResult UpdateSong(Song song)
        {
            return Ok(songRepository.UpdateSong(song));
        }
    }
}
