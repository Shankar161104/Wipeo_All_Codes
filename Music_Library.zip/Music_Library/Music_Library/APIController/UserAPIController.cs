﻿using Domain.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Services.Repository;

namespace Music_Library.APIController
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserAPIController : ControllerBase
    {
        private readonly IUserRepository userRepository;
        public UserAPIController(IUserRepository _userRepository)
        {
            userRepository = _userRepository;
        }


        [HttpGet("GetUsers")]

        public ActionResult GetUsers()
        {
            return Ok(userRepository.GetUsers());
        }


        [HttpPost("Create")]

        public ActionResult CreateUser(User user)
        {
            return Ok(userRepository.CreateUser(user));
        }

        [HttpDelete("Delete")]

        public ActionResult DeleteUser(int id)
        {
            return Ok(userRepository.DeleteUser(id));
        }

        [HttpPost("Update")]

        public ActionResult UpdateUser(User user)
        {
            return Ok(userRepository.UpdateUser(user));
        }


    }
}
