

using DAL.EntityFrameWork;
using Microsoft.EntityFrameworkCore;
using Services.Repository;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<ApplicationDbContext>(tm => tm.UseSqlServer(builder.Configuration.GetConnectionString("MusicConnection"),b=>b.MigrationsAssembly("Music_Library")));
builder.Services.AddTransient<IUserRepository , UserRepository>();
builder.Services.AddTransient<ISongRepository, SongRepository>();
builder.Services.AddTransient<IAlbumRepository, AlbumRepository>();


// Add services to the container.
builder.Services.AddControllersWithViews();





var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=OpeningPage}/{id?}");

app.Run();
