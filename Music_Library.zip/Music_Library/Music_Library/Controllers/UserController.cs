﻿using Domain.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Music_Library.Controllers
{
    public class UserController : Controller
    {
        HttpClient client;
        IConfiguration iconfiguration;

        public UserController(IConfiguration configuration)
        {
            iconfiguration = configuration;
            string apiAddress = iconfiguration["ApiAddress"];
            Uri baseAddress = new Uri(apiAddress);
            client = new HttpClient();
            client.BaseAddress = baseAddress;

            
        }

        public async Task<IActionResult> Index()
        {
            List<User> model = new List<User>();
            HttpResponseMessage res = await client.GetAsync("api/UserAPI/GetUsers");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                model = JsonConvert.DeserializeObject<List<User>>(result);
            }
            return View(model);

        }

       





       
    }
}
