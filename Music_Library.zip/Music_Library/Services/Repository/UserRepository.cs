﻿using DAL.EntityFrameWork;
using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationDbContext dbContext;
        public UserRepository(ApplicationDbContext _dbContext)
        {
            dbContext = _dbContext;
        }
        public int CreateUser(User user)
        {
            dbContext.Users1.Add(user);
            return dbContext.SaveChanges();
        }

        public int DeleteUser(int id)
        {
            var user = dbContext.Users1.Find(id);

            if (user == null)
            {
                throw new ArgumentException($"User with id {id} does not exist.");
            }

            dbContext.Users1.Remove(user);
            return dbContext.SaveChanges();
        }


        public IEnumerable<User> GetUsers()
        {
            return dbContext.Users1.ToList();
        }

        public int UpdateUser(User user)
        {
            dbContext.Users1.Update(user);
            return dbContext.SaveChanges();
        }
    }
}
