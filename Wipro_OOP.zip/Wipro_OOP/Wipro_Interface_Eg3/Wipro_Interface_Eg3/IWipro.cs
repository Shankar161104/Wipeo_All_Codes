﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wipro_Interface_Eg3
{
    public interface IWipro
    {
        string GetFullName(string fname,string lname);
        void Display(string str);
    }
}
