﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wipro_Interface_Eg3
{
    public interface IWiproForGenpact
    {
        int Addition(int a,int b);
    }
}
