﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wipro_Constructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Constructors constructor1 = new Constructors();
            Constructors constructor3 = new Constructors();
            Constructors constructor2 = new Constructors();


        }
    }
    public class Constructors
    {
        public Constructors()
        {
            Console.WriteLine("argergrae");
        }
    }
}
