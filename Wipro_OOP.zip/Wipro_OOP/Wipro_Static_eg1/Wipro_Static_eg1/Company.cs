﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wipro_Static_eg1
{
    public static class Company
    {
        public static int companyID;
        public static string companyName;
        public static string companyAddress;
    }
}
