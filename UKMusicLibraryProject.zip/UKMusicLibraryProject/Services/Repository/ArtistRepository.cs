﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Repository
{
    public class ArtistRepository : IArtistRepository
    {
        public void DeleteArtist(long id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Artist> GetArtist()
        {
            throw new NotImplementedException();
        }

        public Artist GetArtist(long id)
        {
            throw new NotImplementedException();
        }

        public int InsertArtist(Artist artist)
        {
            throw new NotImplementedException();
        }

        public int UpdateArtist(Artist artist)
        {
            throw new NotImplementedException();
        }
    }
}
