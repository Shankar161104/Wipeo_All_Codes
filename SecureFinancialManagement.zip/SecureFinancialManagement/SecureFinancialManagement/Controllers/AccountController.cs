﻿using Microsoft.AspNetCore.Mvc;
using SecureFinancialManagement.Repository;

namespace SecureFinancialManagement.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAccountRepository _accountRepository;

        public AccountController(IAccountRepository accountRepository)
        {
            _accountRepository = accountRepository;
        }

        public IActionResult Index()
        {
            var accounts = _accountRepository.GetAllAccounts();
            return View(accounts);
        }

        public IActionResult Details(int id)
        {
            var account = _accountRepository.GetAccountById(id);
            if (account == null)
            {
                return NotFound();
            }
            return View(account);
        }

        // Other actions for Create, Edit, Delete
    }
}
